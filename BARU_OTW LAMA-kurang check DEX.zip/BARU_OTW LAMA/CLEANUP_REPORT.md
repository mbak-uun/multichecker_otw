Cleanup Report — Unused CSS/JS Removal

Summary
- Goal: Remove unused CSS/JS files and dead code without touching app logic.
- Scope analyzed: All HTML/JS in workspace; resolved local asset references from <script> and <link>.

Detected References
- HTML pages scanned: index.html, modal.html, snapshot_koin.html, manajemen_indexeDB.html
- Local CSS referenced:
  - style.css (index.html)
- Local JS referenced:
  - js/notify-shim.js (index.html, modal.html)
  - idb-localstorage-shim.js (modal.html, snapshot_koin.html)
  - app-namespace.js (index.html)
  - secrets.js (index.html)
  - config.js (index.html)
  - storage.js (index.html)
  - services/cex/registry.js (index.html)
  - utils.js (index.html)
  - services/cex.js (index.html)
  - services/dex.js (index.html)
  - api.js (index.html)
  - main.js (index.html)
  - ui.js (index.html)
  - dom-renderer.js (index.html)
  - scanner.js (index.html)

Removed Files
- services/chain.js
  - Reason: Not referenced by any HTML page and no dynamic inclusion detected; no usages of global "Chain" symbol across codebase. Safe to delete.

Removed In-File Dead Code
- utils.js: getManagedChains()
  - Reason: Not referenced anywhere (only mentioned in a comment). Functionality overlaps with existing helpers; removal is safe and does not change app behavior.

Notes on CSS Selectors
- style.css selectors were cross-checked against HTML and JS-rendered classes/ids. No clearly unused selectors were found. Avoided risky removals to preserve UI behavior.

Risk Assessment
- Deletions are conservative: only assets with zero references/usages were removed.
- No changes to main application logic, IDs, classes, or storage keys.

Validation Hints (manual)
- Load index.html in a browser and check console for errors.
- Open modal.html and snapshot_koin.html to ensure shim scripts load correctly.

Date
- 2025-09-08
